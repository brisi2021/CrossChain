import React from 'react'

import CrossChain from '../../components/CrossChainPanel'

export default function CrossChainBridge() {
  return (
    <>
      <CrossChain bridgeKey={'bridgeTokenList'} />
    </>
  )
}