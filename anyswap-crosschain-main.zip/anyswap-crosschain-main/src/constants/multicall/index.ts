
import MULTICALL_ABI from './abi.json'
export { MULTICALL_ABI }