import TEMP_LOGO from './templogo.png'

export default {
  TEMP_LOGO
}
